mod_quickpublish
================

Joomla admin quick publish module

Joomla Quick Publish Admin Module is a admin side module for joomla developed for j3.1+. The best use of this module is to publish in cpanel position in admin template. It will help to publish article quickly from the joomla admin panel home. BTW, I must mention that I am inspired by the quick edit widget of wordpress. 


For more details please check here http://codeboxr.com/product/joomla-quick-publish-admin-module
